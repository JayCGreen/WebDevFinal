package Models;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.Date;

public class PostModel {
    String post_id;
    UserModel poster;
    String content;
    String caption;
    String postDate;

    public PostModel(String post_id, UserModel poster, String content, String caption, String postDate) {
        this.post_id = post_id;
        this.poster=poster;
        this.content = content;
        this.caption = caption;
        this.postDate = postDate;
    }

    public String getPost_id() {
        return post_id;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCaption() {
        return caption;
    }

    public void setCaption(String caption) {
        this.caption = caption;
    }

    public String getPostDate() {
        return postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public UserModel getPoster() {
        return poster;
    }

    public void setPoster(UserModel poster) {
        this.poster = poster;
    }
}
