package Models;

import Services.MySQLdb;

import java.sql.SQLException;
import java.util.List;

public class UserModel {
    String user_id;
    String username;
    List<UserModel> following;

    public UserModel(String user_id, String username){
        this.user_id = user_id;
        this.username = username;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public List<UserModel> getFollowing() {
        return following;
    }

    public void setFollowing(List<UserModel> following) {
        this.following = following;
    }


}
