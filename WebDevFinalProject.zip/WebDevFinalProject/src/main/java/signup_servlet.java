import Services.MySQLdb;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "signup_servlet", value = "/signup_servlet")
public class signup_servlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String su_name = request.getParameter("name");
        String su_username =  request.getParameter("username");
        String su_password = request.getParameter("password");

        MySQLdb mySQLdb = MySQLdb.getInstance();

        boolean valid = false;
        String userID = null;
        try{
            valid = mySQLdb.dbSignUp(su_name, su_username, su_password);
            System.out.println("Check 1");
            userID= mySQLdb.dbLogin(su_username, su_password);
            System.out.println("Check 2");
        }catch (SQLException e){
            e.printStackTrace();
        }

        if(userID!=null){
            HttpSession session = request.getSession();
            session.setAttribute("user", userID);

            RequestDispatcher requestDispatcher = request.getRequestDispatcher("home.jsp");
            requestDispatcher.forward(request, response);
        }
        else{
            request.setAttribute("error", "Failed to create account");
            RequestDispatcher requestDispatcher = request.getRequestDispatcher("signup.jsp");
            requestDispatcher.forward(request, response);
        }
    }
}
