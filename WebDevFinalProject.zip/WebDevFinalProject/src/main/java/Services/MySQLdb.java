package Services;

import Models.PostModel;
import Models.UserModel;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MySQLdb {
    String url = "jdbc:mysql://localhost:3308/finsta_catalog";
    String username = "root";
    String password = "PassWord";
    static  MySQLdb instance= null;
    Connection connection= null;

    public MySQLdb() {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection(url, username, password);
        } catch (SQLException | ClassNotFoundException exception){
            System.out.println("issues");
            exception.printStackTrace();
        }
    }

    public static synchronized MySQLdb getInstance() {
        if (instance == null){
            instance = new MySQLdb();
        }
        return instance;
    }

    public String dbLogin(String username, String password) throws SQLException{
        UserModel userModel = null;
        String qLogin = "Select user_id FROM users where username = '" + username + "' AND password = '" + password + "'";
        Statement preparedStatement = connection.createStatement();
        ResultSet resultSet = preparedStatement.executeQuery(qLogin);
        String id = null;
        if(resultSet.next()){
            id = resultSet.getString("user_id");
        }
        resultSet.close();
        preparedStatement.close();
        return id;
    }

    public boolean dbSignUp(String name, String username, String password) throws SQLException{
        boolean result = false;
        String count = "Select count(name) as number from users";
        Statement counter = connection.createStatement();
        ResultSet rSet = counter.executeQuery(count);

        int user_id = 1;
        if(rSet.next()){
            user_id = 1 +  rSet.getInt("number");
        }
        System.out.println(user_id);
        counter.close();
        rSet.close();

        String qSignUp = "Insert Into users (user_id, name, username, password) Values (?, ?, ?, ?)";
        PreparedStatement statement = connection.prepareStatement(qSignUp);
        statement.setString(1, ""+user_id);
        statement.setString(2, name);
        statement.setString(3, username);
        statement.setString(4, password);
        int rows_update = statement.executeUpdate();

        if(rows_update>0){
            result = true;
        }

        statement.close();
        return result;
    }

    public List<UserModel> fetchFollowing(String user_id) throws SQLException{
        List<UserModel> following = new ArrayList<>();
        String count = "Select * from connections as C, users as U where C.user_id='" + user_id +
                "' and U.user_id = C.following_id";
        Statement counter = connection.createStatement();
        ResultSet resultSet= counter.executeQuery(count);
        while(resultSet.next()){
            String id = resultSet.getString("following_id");
            String name = resultSet.getString("name");
            String username= resultSet.getString("username");
            UserModel userModel = new UserModel(id, username);
            following.add(userModel);
        }

        counter.close();
        resultSet.close();

        return following;
    }

    public List<PostModel> fetchFeed(List<UserModel> user_id) throws SQLException, IOException {
        List<PostModel> feed = new ArrayList<>();
        for (UserModel id:user_id){
            String query= "Select * from posts where user_id='" + id.getUser_id() + "'";
            Statement counter = connection.createStatement();
            ResultSet resultSet = counter.executeQuery(query);
            while(resultSet.next()){
                String post_id = resultSet.getString("post_id");
                String source = resultSet.getString("content");
                //BufferedImage content = ImageIO.read(source);
                String caption = resultSet.getString("caption");
                Date date = resultSet.getDate("date");
                String d = date.toString();
                PostModel postModel = new PostModel(post_id, id, source, caption, d);
                feed.add(postModel);
            }
        }
        return feed;
    }

    public boolean addPost(String user_id, String content, String caption, String date) throws SQLException{
        boolean result = false;
        String count = "Select count(post_id) as number from posts";
        Statement counter = connection.createStatement();
        ResultSet rSet = counter.executeQuery(count);
        int post_id =1;
        if(rSet.next()){
            post_id = 1 +  rSet.getInt("number");
        }
        System.out.println(post_id);
        counter.close();
        rSet.close();
        String query = "Insert into posts(post_id, user_id, content, caption, date) values('"+
                post_id +"', '"+ user_id + "', '"+ content + "', '" + caption +"', '"+date +"')" ;
        Statement statement = connection.createStatement();;
        int check = statement.executeUpdate(query);
        if(check > 0){
            result = true;
        }
        statement.close();
        return result;
    }

    public List<UserModel> getAllUsers() throws SQLException {
        List<UserModel> following = new ArrayList<>();
        String count = "Select * from users";
        Statement counter = connection.createStatement();
        ResultSet resultSet= counter.executeQuery(count);
        while(resultSet.next()){
            String id = resultSet.getString("user_id");
            String name = resultSet.getString("name");
            String username= resultSet.getString("username");
            UserModel userModel = new UserModel(id, username);
            following.add(userModel);
        }

        counter.close();
        resultSet.close();

        return following;
    }

    public boolean follow(String follower_id, String following_id) throws SQLException{
        boolean result = false;

        String query = "Insert into connections(user_id, following_id ) values('"+
                follower_id + "', '" + following_id +"')" ;
        Statement statement = connection.createStatement();;
        int check = statement.executeUpdate(query);
        if(check > 0){
            result = true;
        }
        return result;
    }

    public boolean unfollow(String follower_id, String following_id) throws SQLException{
        boolean result = false;

        String query = "delete from connections where user_id='"+
                follower_id + "' and following_id='" + following_id +"'" ;
        Statement statement = connection.createStatement();;
        int check = statement.executeUpdate(query);
        if(check > 0){
            result = true;
        }
        return result;
    }
}
